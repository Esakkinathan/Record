//
//  ListPasswordViewController.swift
//  record
//
//  Created by Esakkinathan B on 03/02/26.
//

import UIKit

class ListPasswordViewController: KeyboardNotificationViewController {
    
    let tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .insetGrouped)
        tableView.rowHeight = UITableView.automaticDimension
        tableView.contentInsetAdjustmentBehavior = .automatic
        return tableView
        
    }()
    override var keyboardScrollableView: UIScrollView? {
        return tableView
    }

    let timerLabel: UILabel = {
        let label = UILabel()
        label.font = AppFont.body
        label.backgroundColor = AppColor.primaryColor
        label.labelSetUp()
        return label
    }()
    
    let sortView: SortHeaderView = {
        let view = SortHeaderView()
        view.button.configuration?.title = "Options"
        view.setTimerViewHidden(false)
        view.button.configuration?.image = nil
        return view
    }()
    
    let searchController = UISearchController(searchResultsController: nil)
    
    var presenter: ListPasswordProtocol!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = AppColor.background
        tableView.backgroundColor = AppColor.background
        setUpNavigationBar()
        presenter.viewDidLoad()
        setUpContents()
    }
        
    func setUpNavigationBar() {
        title = "Password Manager"
        navigationController?.navigationBar.isTranslucent = false
        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addButtonClicked))
        
        let spacer = UIBarButtonItem(
            barButtonSystemItem: .fixedSpace,
            target: nil,
            action: nil
        )
        spacer.width = 12

        navigationItem.rightBarButtonItem = addButton
        navigationItem.largeTitleDisplayMode = .never
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(systemName: IconName.cancel), style: AppConstantData.buttonStyle, target: self, action: #selector(exitClicked))
        
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search"
        searchController.searchBar.searchBarStyle = .minimal
        //searchController.searchBar.backgroundImage = UIImage()
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = true
        definesPresentationContext = true
        

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        presenter.viewWillAppear()
    }
    func setUpContents() {
        view.add(tableView)
        view.add(sortView)
        
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.register(ListPasswordCell.self, forCellReuseIdentifier: ListPasswordCell.identifier)
        
        NSLayoutConstraint.activate([
            sortView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor,constant: PaddingSize.height),
            sortView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: PaddingSize.width * 2 ),
            sortView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -PaddingSize.width),

            tableView.topAnchor.constraint(equalTo: sortView.bottomAnchor, constant: PaddingSize.height),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -PaddingSize.height),
            tableView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor)
        ])

    }

}

extension ListPasswordViewController {
    
    @objc func addButtonClicked() {
        presenter.gotoAddPasswordScreen()
    }
    
    @objc func exitClicked() {
        presenter.exitClicked()
    }
    
    func buildSortMenu() {
        let current = presenter.currentSort

        func subtitle(
            field: PasswordSortField,
            asc: String,
            desc: String
        ) -> String {
            guard current.field == field else { return asc }
            return current.direction == .ascending ? asc : desc
        }

        let name = UIAction(
            title: "Title",
            subtitle: subtitle(
                field: .title,
                asc: "Ascending",
                desc: "Descending"
            ),
            state: current.field == .title ? .on : .off
        ) { [weak self] _ in
            self?.presenter.didSelectSortField(.title)
        }

        let created = UIAction(
            title: "Created At",
            subtitle: subtitle(
                field: .createdAt,
                asc: "Newest to Oldest",
                desc: "Oldest to Newest"
            ),
            state: current.field == .createdAt ? .on : .off
        ) { [weak self] _ in
            self?.presenter.didSelectSortField(.createdAt)
        }

        let updated = UIAction(
            title: "Updated At",
            subtitle: subtitle(
                field: .updatedAt,
                asc: "Newest to Oldest",
                desc: "Oldest to Newest"
            ),
            state: current.field == .updatedAt ? .on : .off
        ) { [weak self] _ in
            self?.presenter.didSelectSortField(.updatedAt)
        }

        let favorite = UIAction(
            title: "Favourite",
            state: presenter.isFavoriteSelected ? .on : .off
        ) { [weak self] _ in
            self?.presenter.didSelectedFavourite(reset: true)
        }
        let filterMenu = UIMenu(
            title: "Filter",
            options: .displayInline,
            children: [favorite]
        )
        
        let sortMenu = UIMenu(
            title: "Sort By",
            options: .displayInline,
            children: [name, created, updated]
        )

        
        sortView.configure(text: current.field.rawValue)
//        DispatchQueue.main.async { [weak self] in
            sortView.button.menu = UIMenu(
                title: "",
                children: [filterMenu, sortMenu]
            )

//        }
    }
    

}

extension ListPasswordViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        presenter.numberOfPasswords()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let password = presenter.password(at: indexPath.row)
        
        let cell = tableView.dequeueReusableCell(
            withIdentifier: ListPasswordCell.identifier
        ) as! ListPasswordCell
                
        cell.configure(password.title, password.username, isFavourite: password.isFavorite)
        cell.onFavoriteButtonClicked = { [weak self] in
            self?.presenter.toggleFavorite(password)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: AppConstantData.delete) { [weak self] _, _, completion in
            self?.presenter.deleteClicked(at: indexPath.row)
            completion(true)
        }
        
        deleteAction.image = UIImage(systemName: IconName.trash)
        let swipeAction = UISwipeActionsConfiguration(actions: [deleteAction])
        swipeAction.performsFirstActionWithFullSwipe = true
        return swipeAction
    }

}

extension ListPasswordViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        presenter.didSelectedRow(at: indexPath.row)
    }
}

extension ListPasswordViewController: ListPasswordViewDelegate {
    func showToastVC(message: String, type: ToastType) {
        showToast(message: message, type: type)
    }
    
    func refreshSortMenu() {
        buildSortMenu()
    }
    func showAlertOnDelete(at index: Int) {
        let alert = UIAlertController(
            title: "Delete?",
            message: "Are you sure you want to delete?",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "No", style: .cancel))
        
        alert.addAction(UIAlertAction(title: "Yes", style: .destructive) { [weak self] _ in
            self?.presenter.deletePassword(index: index)
        })
        present(alert, animated: true)
    }

    func reloadData() {
        tableView.reloadData()
        let isEmpty = presenter.isEmpty
        let isSearching = presenter.isSearching
        sortView.isHidden = isSearching && isEmpty
        if isEmpty {
            if !isSearching {
                tableView.setEmptyView(image: "key.slash", title: "No Passwords", subtitle: "Tap + on top to create your first password.")

            } else {
                tableView.setHeaderEmptyView(image: "key.slash", title: "No Matching Password Found", subtitle: "Search with Password title and user name")
            }
        } else {
            tableView.restoreView()
        }

    }
    func reloadCellAt(_ indexRow: Int) {
        tableView.reloadRows(at: [IndexPath(row: indexRow, section: 1)], with: .automatic)
    }
    func dismiss() {
        if presentedViewController != nil {
            dismiss(animated: false) { [weak self] in
                self?.navigationController?.dismiss(animated: true)
            }
        } else {
            navigationController?.dismiss(animated: true)
        }
    }
    
    func updateTimer(_ time: String) {
        let fullText = "Auto exit in \(time)"
        let attributed = NSMutableAttributedString(string: fullText)

        // Find range of number part
        if let range = fullText.range(of: time) {
            let nsRange = NSRange(range, in: fullText)
            
            attributed.addAttribute(
                .foregroundColor,
                value: UIColor.red,
                range: nsRange
            )
        }

        sortView.setTimer(text: attributed)
    }
    
    func showExitPrompt(expired: Bool) {

        let title = expired ? "Session Expired" : "Exit Passwords?"
        var message = expired ? "Do you want to stay for another \(AppConstantData.passwordSession / 60) minutes?" :  "Are you sure want to exit?"
        message += " Auto Exit in \(AppConstantData.autoExitTime) seconds"

        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Stay", style: .default) { [weak self] _ in
            if expired {
                self?.presenter.extendSession()
            } else {
                self?.presenter.stopAutoExitTimer()
            }
            
        })

        alert.addAction(UIAlertAction(title: "Exit", style: .destructive) { [weak self] _ in
            self?.presenter.exitPassoword()
        })


        present(alert, animated: true)
    }
    
}

extension ListPasswordViewController: DocumentNavigationDelegate {
    func presentVC(_ vc: UIViewController) {
        present(vc, animated: true)
    }
    
    func push(_ vc: UIViewController) {
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
}

extension ListPasswordViewController: UISearchResultsUpdating, UISearchBarDelegate {
    
    func updateSearchResults(for searchController: UISearchController) {
        guard let text = searchController.searchBar.text?.trimmingCharacters(in: .whitespacesAndNewlines) else {return}
        presenter.search(text: text)
    }
    
}
